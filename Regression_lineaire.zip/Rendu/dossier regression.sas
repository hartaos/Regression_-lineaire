**********************************************Dossier regr�ssion logisitique*; *******************************************************************
                                               ***********************************;


PROC IMPORT OUT= Erfi.repondant 
            DATAFILE= "C:\Users\gaeta\OneDrive\Documents\L1\regression logistique\Erfi\repondant.sas7bdat" 
            DBMS=SPSS REPLACE;

RUN;
libname Erfi "C:\Users\gaeta\OneDrive\Documents\L1\regression logistique\repondant" ;

data work.repondant;
    set "C:\Users\gaeta\OneDrive\Documents\L1\regression logistique\Erfi\repondant.sas7bdat";
run;
* ici la bdd se trouve dans work*; 
*cette ligne cr�� une bdd avec un nom random*; 


proc freq data = work.Repondant ;
table FB_MOYEN_1 ;
run ;

*Ici la variable FB_MOYEN_1 d�signe les gens qui utilise un moyen de contraception et nottament le preservatif(ici les moyens
de contraceptions sont associ�s a des chiffres = 1 repr�sentant un moyen de contraception , 2 un autre etc... 
Les nombre diff�rents de moyens de contraception allant jusqu'a 13 ) *; 

proc freq data = work.Repondant ;
table FB_MOYEN_2 ;
run ;

* le FB_MOYEN_2 sont les gens qui utilise la pilule comme moyen de contraception *; 

* je fais un format *; 

proc format ; 
value $pilule 
0 = "n'utilise pas la pilue" 
1 ="utilise la pilule" ;
run ;


proc freq data = work.Repondant ;
format FB_MOYEN_2 $pilule. ; 
table FB_MOYEN_2 ;
run ;
*ici j'applique le format pour v�rifier si celui-ci � marcher et voir comment la variable est constitu�, 
on voit qu'il y a des valeurs manquante pour faire un mod�le de r�gr�ssion lin�aire il est n�c�ssaire que celui-ci 
n'est pas de valeurs manquante dans les donn�es utilis� je fais donc le choix avec d'autre variable contenant des valeurs manquante 
de cr�� une nouvelle base de donn�es ne contenant aucune valeurs manquante pour ainsu pouvoir faire mon mod�les propremment. 


***************************************************************Cr�ation base de donn�es***********************************************************
*************************************************************************************************************************************************;

*Le choix de la variable dichotomique induit plusieurs modification dans la base de donn�es il faut tout d'abord ne garder que les personnes 
utilisant la pilule comme moyen de contraception *;

data extrait2 ; 
set work.Repondant ; 
where FB_MOYEN_2 ne "" ;
run ;
*� la suite de se recoupage on ne souhaite garder que les femmes en effet la  base de donn�es datant de 2005 la pilule masculine est 
quasiment inconnue*; 

data extrait2 ; 
set extrait2 ; 
where MA_SEXE ne "1" ; 
run ; 

data extrait2 ;
set extrait2 ;
where CA_ADEBCOH ne "" ;
run ; 
* Ann�e de d�but de vie de couple avec le conjoint cohabitant le pb �tant les personne pas en couple *; 

*Cat�gorie socioprofessionnelle (PCS) du r�pondant*;
data extrait2;
  set extrait2;
  /* Recoder les individus sans emploi en les codant comme "0" */
  if AH_PCS8 = "" then AH_PCS8 = "0";
run;

*Cat�gorie socioprofessionnelle (PCS) du conjoint du r�pondant en 8 postes*;
data extrait2;
  set extrait2;
  /* Recoder les individus sans emploi en les codant comme "0" */
  if RH_PCS8 = "" then RH_PCS8 = "0";
run;


data extrait2;
  set extrait2;
  /* Recoder les individus sans emploi en les codant comme "0" */
  if AH_STATUT = "" then AH_STATUT = "0";
run;

data extrait2;
  set extrait2;
  /* Recoder les individus qui ne sont pas en couple en les codant comme "0" */
  if CA_ADEBCOH = "" then CA_ADEBCOH = "0";
run;





**********************************************************************************************************************************************
*********************************************Choix des variables expliactive******************************************************************
*********************************************************************************************************************************************;



***************Format*************
*********************************;

*en couple ou non *;
proc format ;
value $couple 
1 = "en couple"
2 = "pas en couple" ;
run ; 
* cat�gorie d'age *; 
proc format ;
value age  
18-25 = "18-25"
26-30 = "25-30" 
31-35 = "30-35"
36-40 = "35-40"
41-50 = "40-50"
51-60 = "50-60"
61-high = "60-76" ; 
run ; 
* nombre d'enfants *;
proc format ; 
value nbenf 
0 = "0"
1 = "1"
2 = "2"
3 = "3"
4 = "4"
5-high = "6 ou plus" ; 
run ; 
* type de famille*; 
proc format ;
value $type_fam
110,120,200 = "seuls"
311,312,313,321,322,323 ="Famille monoparentale"
400="couple sans enfant" 
401,402,403="couple avec enfant" ; 
run ; 
* niveau de diplome *;
proc format ;
value $diplm 
1,2,3,4 = "inf�rieur au bac" 
5,6 = "Bac" 
7,8 = "sup�rieur au bac" ; 
run;
* trance de revenue par mois *; 
proc format ; 
value $rev
1 = "499 � ou moins" 
2  = "De 500 � � 999 �" 
3  = "De 1 000 � � 1 499 �" 
4  = "De 1 500 � � 1 999 �" 
5,99  = "De 2 000 � � 2 499 �" 
6  = "De 2 500 � � 2 999 �" 
7,98 =  "De 3 000 � � 4 999 �" 
8 =  "5 000 � ou plus" ;
run ;
* csp du r�pondant *; 
proc format ; 
value $csprep 
0 = "ne travaille pas" 
1 = "Agriculteurs"   
2 = "Artisans, commer�ants et chefs d'entreprise"   
3 = "Cadres et professions intellectuelles sup�rieures"  
4 = "Professions interm�diaires"   
5,9 = "Employ�s"   
6 = "Ouvriers"   ;
run ;
* csp du conjoint*; 
proc format ;
value $cspconj
0 = "ne travaille pas"
1 = "Agriculteurs"   
2 = "Artisans, commer�ants et chefs d'entreprise"   
3 = "Cadres et professions intellectuelles sup�rieures"   
4 = "Professions interm�diaires"  
5,9 = "Employ�s"   
6 = "Ouvriers" ;
run ; 
*trance d'anciennt� du couple selon la d�claration de date de mise en couple *; 
proc format;
    value $anciennete_couple
		0 = "pas en couple"
        1900 - 1954 = "Plus de 50 ans"
        1955 - 1964 = "40 � 50 ans"
        1965 - 1974 = "30 � 40 ans"
        1975 - 1984 = "20 � 30 ans"
        1985 - 1994 = "10 � 20 ans"
        1995 - 2005,9999 = "Moins de 10 ans";
run;
proc format;
value $natio
01="Fran�aise"
02,03="Europ�enne"
04,05,06="Reste du monde" ;
run; 



**********************************
********proc/trie crois�**********
*********************************;
ods tagsets.excelxp file="C:\Users\gaeta\OneDrive\Documents\L1\regression logistique\tableau_croise.ods" 
    style=statistical 
    options(sheet_name="Tableaux Crois�s" embedded_titles='yes' gridlines='yes');

proc freq data = extrait2 ;
table EA_VERIFC*FB_MOYEN_2 /chisq ;
format FB_MOYEN_2 $pilule.  EA_VERIFC $couple. ; 
run ;


ods tagsets.excelxp close;


* on vas maintant essay� avec l'age *; 

proc freq data = extrait2 ;
table MA_AGEM*FB_MOYEN_2 /chisq ;
format FB_MOYEN_2 $pilule.  MA_AGEM age. ; 
run ;

*le nombre d'enfant eu peut avoir un impact *; 

proc freq data = extrait2 ;
table NBENFTOT*FB_MOYEN_2 /chisq ;
format FB_MOYEN_2 $pilule.  NBENFTOT nbenf. ; 
run ;

 *type de famille *;
proc freq data = extrait2 ;
table TYPFAM*FB_MOYEN_2 /chisq ;
format FB_MOYEN_2 $pilule.  TYPFAM $type_fam. ; 
run ;

* ici on fait le niveau de diplome *; 
proc freq data = extrait2 ;
table MC_DIPLOME*FB_MOYEN_2 /chisq ;
format FB_MOYEN_2 $pilule. MC_DIPLOME $diplm. ; 
run ;

*ici on prend la varaible revenue d�clarer du m�nage (car I seuls = m�nage) *;
proc freq data = extrait2 ;
table BC_FOUREVMEN*FB_MOYEN_2 /chisq ;
format FB_MOYEN_2 $pilule. BC_FOUREVMEN $rev. ; 
run ;

*AH_PCS8 cat�gorie socio-profesionnelle du r�pondant*;

proc freq data = extrait2 ;
table AH_PCS8*FB_MOYEN_2 /chisq ;
format FB_MOYEN_2 $pilule. AH_PCS8 $csprep. ; 
run ;

*RH_PCS8 Cat�gorie socioprofessionnelle (PCS) du conjoint du r�pondant en 8*; 
proc freq data = extrait2 ;
table RH_PCS8*FB_MOYEN_2 /chisq ;
format FB_MOYEN_2 $pilule. RH_PCS8 $cspconj. ; 
run ;


*CA_ADEBCOH Ann�e de d�but de vie de couple avec le conjoint cohabitant *; 

proc freq data = extrait2 ;
table CA_ADEBCOH*FB_MOYEN_2 /chisq ;
format FB_MOYEN_2 $pilule. CA_ADEBCOH $anciennete_couple. ; 
run ;

* la nationalit� du r�pondant*; 
proc freq data = extrait2 ;
table ma_natior*FB_MOYEN_2 /chisq ;
format FB_MOYEN_2 $pilule. ma_natior $natio. ; 
run ;


ods tagsets.excelxp close;

**************************************************************************************************************************************************
*******************************************************Mod�le de r�gression logistique************************************************************
*************************************************************************************************************************************************;
ods tagsets.excelxp file="C:\Users\gaeta\OneDrive\Documents\L1\regression logistique\proc_logis.ods" 
    style=statistical 
    options(sheet_name="proc_logis" embedded_titles='yes' gridlines='yes');

proc logistic data = extrait2 ;
class RH_PCS8(ref="Employ�s")
      AH_PCS8(ref="Employ�s")
	  BC_FOUREVMEN(ref="De 1 000 � � 1 499 �")
	  NBENFTOT(ref="1")
      EA_VERIFC(ref="en couple")
	  ma_agem(ref ="25-30")
	  typfam(ref ="couple avec enfant")
	  mc_diplome(ref="Bac")
      ma_natior(ref="Fran�aise")
	  CA_ADEBCOH(ref="Moins de 10 ans")

/ param=ref ;
model FB_MOYEN_2= ma_agem typfam mc_diplome 
      RH_PCS8 AH_PCS8 BC_FOUREVMEN NBENFTOT EA_VERIFC ma_natior CA_ADEBCOH; 

format FB_MOYEN_2 $pilule.
       ma_agem age.
       typfam $Type_fam.
       mc_diplome $diplm.
       RH_PCS8 $cspconj.
       AH_PCS8 $csprep.
       BC_FOUREVMEN $rev.
       NBENFTOT nbenf.
       EA_VERIFC $couple.
	   ma_natior $natio.
       CA_ADEBCOH $anciennete_couple.; 
	   run ; 
ods tagsets.excelxp close;
